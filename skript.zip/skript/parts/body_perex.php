<section>
    <div class="container">
        <div class="col-100 text-center">
            <p><strong><em>Elit culpa id mollit irure sit. Ex ut et ea esse culpa officia ea incididunt elit velit veniam qui. Mollit deserunt culpa incididunt laborum commodo in culpa.</em
                    ></strong></p>
        </div>
    </div>
</section>